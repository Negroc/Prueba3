package com.example.warm_eva2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.warm_eva2.databinding.ActivityRegistrarBinding
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth


class registrarActivity : AppCompatActivity() {


private lateinit var binding : ActivityRegistrarBinding



private lateinit var auth: FirebaseAuth


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegistrarBinding.inflate(layoutInflater)
        setContentView(binding.root) // Use binding.root to set the content view

        // Iniciar el auth
        auth = Firebase.auth

        binding.btnRegistrar.setOnClickListener {
            // Los datos a registrar
            val correo: String = binding.userNuevo.text.toString()
            val contra: String = binding.contranu.text.toString()
            val contra2: String = binding.contranu2.text.toString()

            // Verificar que los datos no son vacíos
            if (correo.isEmpty()) {
                binding.userNuevo.error = "Ingresar correo"
                return@setOnClickListener // Para el usuario
            }
            if (contra.isEmpty()) {
                binding.contranu.error = "Ingresar Contraseña"
                return@setOnClickListener // Para la contraseña
            }
            if (contra2.isEmpty()) {
                binding.contranu2.error = "Confirma Contraseña"
                return@setOnClickListener // Para la confirmación de la contraseña
            }

            if (contra == contra2) {
                registrarUsuario(correo, contra)
            }
        }
    }

    private fun registrarUsuario(email: String, password: String){
        auth.createUserWithEmailAndPassword(email,password)
            .addOnCompleteListener{
                if(it.isSuccessful){
                    Toast.makeText(this, "el usuario se ha creado correctamente", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                }else{
                    Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show()
                }

            }

}



}


