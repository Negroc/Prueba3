package com.example.warm_eva2
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.warm_eva2.Nav_activity
import com.example.warm_eva2.R
import com.example.warm_eva2.databinding.ActivityMainBinding
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth

class MainActivity : AppCompatActivity() {

    private lateinit var binding : ActivityMainBinding



    private lateinit var auth : FirebaseAuth





    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

//iniciar el auth
         auth = Firebase.auth


//crear el login

        binding.buttonLogin.setOnClickListener {

            val correo = binding.idUsername.text.toString()
            val contrasena = binding.idPassword.text.toString()


            if(correo.isEmpty()){
                binding.idUsername.error = "Ingresa un Correo"//para confirmar correo
                return@setOnClickListener

            }

            if(contrasena.isEmpty()){
                binding.idPassword.error = "Ingresa una contraseña"// para confirmar contraseña
                return@setOnClickListener
            }

            singIn(correo,contrasena)



        }

//inciar actividad
        binding.btregistrar.setOnClickListener{
            val intent = Intent(this,registrarActivity::class.java)
            startActivity(intent)

        }

    }
//mensajes de inicio de sesion


    private fun singIn(email: String, password: String) {

        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener {
                if(it.isSuccessful){
                    Toast.makeText( this,"Inicio de sesion Correcto",Toast.LENGTH_SHORT).show()
                    val intent = Intent(this,Nav_activity::class.java)
                    startActivity(intent)
                } else{
                    Toast.makeText( this,"Error",Toast.LENGTH_SHORT).show()
                }
            }


    }


}